-- File: conquest.lua
-- Catalog: script\multiplayer\modes
-- Modify by Max Drechsler 
-- Edited 28.08.2026
-- Version 1.13 (финальная, с встроенным спавном)

-- < [ ADD ARM START ]:
local CostTracker = require([[/script/multiplayer/modes/conquest_cost_tracker]])				-- dev
--require([[/script/multiplayer/modes/log_filter]])												-- not work
require([[/script/multiplayer/modes/utility]])													-- main LUA utility
require([[/script/multiplayer/modes/conquest_lair]])											-- its replacer addon
require([[/script/multiplayer/modes/conquest_np]])												-- its replacer addon
--require([[/script/multiplayer/modes/conquest_para]])											-- to del
local UnitFilter = require([[/script/multiplayer/modes/conquest_type_filter]])					-- its work
local UnitLimiter = require([[/script/multiplayer/modes/conquest_limiter]])						-- its work
-- local ResourcesDebug = require([[/script/multiplayer/modes/debug_resources]])   				-- not work
local Doctrine = require([[/script/multiplayer/modes/conquest_doctrine]])						-- need rework
local TankInfantryRatio = require([[/script/multiplayer/modes/conquest_tank_infantry_ratio]])	-- its work
local Multiplier = require([[/script/multiplayer/modes/conquest_unit_multiplier]])				-- dev

-- > [ ADD ARM END ]:

-- < [ ADD ARM START ]:
local botDefender = false
local currentBattleNumber = 1   -- будет обновляться в OnGameStart

local function isAttackerOrDefender()
	if BotApi.Conquest and BotApi.Conquest.Attacking then
		botDefender = false  -- false = attacker
	else
		botDefender = true   -- true = defender
	end

	if printDebug then
		print("[ARM] Print: botDefender = " .. tostring(botDefender))
	end
end
-- > [ ADD ARM END ]:

-- Time from start of match AI will wait before attempting to buy a unit.
local StartSpawnTime = {
	-- Bot is defender
	DefenseMin = 2 * 60 * 1000, 
	DefenseMax = 3 * 60 * 1000,
	-- Bot is attacker. Controlled by preptime now. 
	AttackMin = 1 * 1000, 
	AttackMax = 1 * 1000,
}

-- Time from last purchase AI will wait before attempting to buy a new unit.
-- Values are in milliseconds.
local SpawnCooldownTimeByDifficulty = {
	easy = {
		-- Time between each wave
		DCGWaveOffMin = 1.75 * 60 * 1000,
		DCGWaveOffMax = 2.25 * 60 * 1000,

		-- Time between each spawn
		DCGMin = 2 * 1000,
		DCGMax = 2 * 1000,
	},

	normal = {
		DCGWaveOffMin = 2.00 * 60 * 1000,
		DCGWaveOffMax = 2.50 * 60 * 1000,
		-- Time between each spawn
		DCGMin = 2 * 1000,
		DCGMax = 2 * 1000,
	},

	hard = {
		DCGWaveOffMin = 2.25 * 60 * 1000,
		DCGWaveOffMax = 2.75 * 60 * 1000,
		-- Time between each spawn
		DCGMin = 2 * 1000,
		DCGMax = 2 * 1000,
	},

	heroic = {
		DCGWaveOffMin = 2.50 * 60 * 1000,
		DCGWaveOffMax = 3.00 * 60 * 1000,
		-- Time between each spawn
		DCGMin = 2 * 1000,
		DCGMax = 2 * 1000,
	},
}

-- [ BACKUP START ]:
-- local WaveUnitByDifficulty = {
-- 	easy = { Min = 6, Max = 12, },
-- 	normal = { Min = 10, Max = 18, },
-- 	hard = { Min = 15, Max = 20, },
-- 	heroic = { Min = 18, Max = 32, },
-- }
-- [ BACKUP END ]:

-- << [ ARM REPLACER START ]:
-- Number of possible units that can be in a wave attack.
local WaveUnitByRoleAndDifficulty = {
	easy = {
		defender = { Min = 7, Max = 11 },
		attacker = { Min = 15, Max = 18 },
	},
	normal = {
		defender = { Min = 9, Max = 13 },
		attacker = { Min = 17, Max = 20 },
	},
	hard = {
		defender = { Min = 11, Max = 15 },
		attacker = { Min = 19, Max = 22 },
	},
	heroic = {
		defender = { Min = 13, Max = 17 },
		attacker = { Min = 21, Max = 24 },
	},
}

-- < [ ADD ARM START ]:
-- Множитель количества юнитов в зависимости от номера битвы
local function getBattleMultiplier(battleNumber)
    if battleNumber <= 1 then
        return 1.0
    elseif battleNumber <= 2 then
        return 1.0
    else
        return 1.1
    end
end

local function roundToInt(x)
	return math.floor(x + 0.5)
end
-- > [ ADD ARM END ]
-- >> [ ARM REPLACER END ]

local function GetBotDifficultyKey()
	return BotApi.Instance.difficulty or "normal"
end

local function GetStartSpawnTime()
	return StartSpawnTime
end

local function GetSpawnCooldownTime()
	return SpawnCooldownTimeByDifficulty[GetBotDifficultyKey()] or SpawnCooldownTimeByDifficulty.normal
end

-- < [ ARM REPLACER START ]:
local function GetWaveUnit()
    local difficulty = GetBotDifficultyKey()
    local roleTable = WaveUnitByRoleAndDifficulty[difficulty] or WaveUnitByRoleAndDifficulty.normal
    local roleKey = botDefender and "defender" or "attacker"
    local base = roleTable[roleKey] or roleTable["defender"]

    local mult = getBattleMultiplier(currentBattleNumber)
    local adjustedMin = roundToInt(base.Min * mult)
    local adjustedMax = roundToInt(base.Max * mult)
    if adjustedMin > adjustedMax then
        adjustedMin, adjustedMax = adjustedMax, adjustedMin
    end

    if printDebug then
        print(string.format("[ARm] (WAve): Multiplier applied: %.2f (based on defense level %d)", mult, currentBattleNumber))
        print(string.format("[ARm] (WAve): Base: %d-%d -> Adjusted: %d-%d (role: %s, diff: %s)",
            base.Min, base.Max, adjustedMin, adjustedMax, roleKey, difficulty))
    end

    return { Min = adjustedMin, Max = adjustedMax }
end
-- > [ ARM REPLACER END ]

-- [ BACKUP START ]:
-- local function RollWaveUnitTotal()
-- 	local waveUnit = GetWaveUnit()
-- 	return math.random(waveUnit.Min, waveUnit.Max)
-- end
-- [ BACKUP END ]:

-- [ REWRITE ARM START ]:
local function RollWaveUnitTotal()
    local waveUnit = GetWaveUnit()
    if not waveUnit or not waveUnit.Min or not waveUnit.Max then
        if printDebug then
            print("[ARm] (WAve): ERROR: Invalid waveUnit, using fallback 10")
        end
        return 10
    end
    local total = math.random(waveUnit.Min, waveUnit.Max)
    if printDebug then
        print(string.format("[ARm] (WAve): Rolled %d units for this wave (multiplier: %.2f)", total, getBattleMultiplier(currentBattleNumber)))
    end
    return total
end
-- [ REWRITE ARM END ]

local AmbushEventState = {
	active = false,
	warning = false,
	relocating = false,
	spawning = false,
	restoring = false,
	spawned = 0,
	target = 10,
}

local ambushEventTriggered = false
local ambushWarningTimer = nil

local AMBUSH_STALL_TIMEOUT = 30 * 1000
local ambushStallTimer = nil

-- Sets time limit AI will wait for a unit it has chosen to buy if the unit is not yet available
local UnitSpawnWaitTime = 1.5 * 60000 -- 1:30min (ms) 

-- Time delay for units to get a new move order after spawn move order. Loops.
local OrderRotationPeriod = 2.5 * 60000 -- 2:30 min (ms)

-- [ BACKUP START ]:
-- local botDefender
-- enableWaveCounter = true
-- [ BACKUP END ]:

-- < [ ADD ARM START ]:
local enableWaveCounter = true
-- > [ ADD ARM END ]:

local waveSpawnPossible
local waveSpawnActive = true
local waveUnitCount = 0
local waveNumber = 0
local waveUnitTotal = 0

local firstPurchase = true
local conquestSpawnPointIndex = 0

local spawningUnit = false   -- <-- добавлено для работы спавна

function GameModeSpawnUnit(unit, maxSquadSize)
	if BotApi.Commands:SpawnAt(unit, maxSquadSize, conquestSpawnPointIndex) then
		conquestSpawnPointIndex = conquestSpawnPointIndex + 1
		return true
	end

	return false
end

-- [ DEL ARM START ]:
-- local function isAttackerOrDefender()
--	botDefender = not BotApi.Conquest.Attacking
--	if printDebug then print("Print: botDefender", botDefender) end
-- end
-- [ DEL ARM END ]:

local function setVarsInMissionScript()
	-- Mission script var is from the user's perspective.
	BotApi.Scene:SetVar("user_is_defender", botDefender and 0 or 1)

	local nationMap = { rus = 1, ger = 2, fin = 3, usa = 4, eng = 5, jap = 11 }
	local difficultyMap = { easy = 1, normal = 2, hard = 3, heroic = 4 }
	local spawnMap = { a = 1, b = 2 }
	local playerSpawnNameMap = {
		a1 = 1, a2 = 2, a3 = 3, a4 = 4,
		b1 = 5, b2 = 6, b3 = 7, b4 = 8,
	}

	BotApi.Scene:SetVar("bot_army", nationMap[BotApi.Instance.army] or 0)
	BotApi.Scene:SetVar("bot_difficulty", difficultyMap[BotApi.Instance.difficulty] or 0)
	BotApi.Scene:SetVar("bots_spawnside", spawnMap[spawnSide] or 0)
	BotApi.Scene:SetVar("player_spawn_name", playerSpawnNameMap[BotApi.Conquest.PlayerSpawnPoint] or 0)

	BotApi.Scene:SetVar("enemyid", BotApi.Instance.playerId)
	BotApi.Scene:SetVar("id_1st_enemy", BotApi.Conquest.FirstEnemyId)
	BotApi.Scene:SetVar("id_defenderbot", BotApi.Conquest.DefenderBotId)
	BotApi.Scene:SetVar("id_1st_player", BotApi.Conquest.FirstPlayerId)
end

function WaveAttack()
	waveSpawnPossible = true

	if waveUnitCount >= waveUnitTotal then
		waveUnitTotal = RollWaveUnitTotal()

		if printDebug then
			print("[ARM] Print: waveUnitTotal", waveUnitTotal)
		end

		waveSpawnActive = false
		waveUnitCount = 0
		waveNumber = waveNumber + 1

		if printDebug then
			print("[ARM] Print: waveNumber", waveNumber)
		end
	else
		waveSpawnActive = true
	end
end

function WaveUnitCounter()
	if waveSpawnPossible then
		waveUnitCount = waveUnitCount + 1
		if printDebug then print("[ARM] Print: waveUnitCount =", waveUnitCount) end
	end
end

function table.shuffle(tbl)
	local rand = math.random
	for i = #tbl, 2, -1 do
	  local j = rand(i)
	  tbl[i], tbl[j] = tbl[j], tbl[i]
	end
	return tbl
end
  
-- Function to shuffle the flags table
local function shuffleFlags(flags)
	if waveNumber <= 1 then
		table.sort(flags, function(a, b) return a.name < b.name end)
	else
		table.shuffle(flags)
	end
end

-- Function to calculate flag priority for attacker
local function calculateAttackerPriority(f, enemyTeam, team, firstEnemyFlagEncountered)
    if f.owner == enemyTeam and not firstEnemyFlagEncountered then
        firstEnemyFlagEncountered = true
        return f.priority, firstEnemyFlagEncountered
    elseif f.owner == enemyTeam or f.owner == team then
        return f.priority * 0, firstEnemyFlagEncountered
    end
    return f.priority, firstEnemyFlagEncountered
end

-- Function to calculate flag priority for defender
local function calculateDefenderPriority(f, enemyTeam, team)
    if f.owner == enemyTeam then
        return f.priority * 2
    elseif f.owner == team then
        return f.priority * 0.5
    end
    return f.priority
end

function GetFlagToCapture(flagPoints, getPriority, flags)
	local alliedFlags, opponentFlags, neutralFlags, totalFlags = CalculateFlagStatistics(BotApi.Scene.Flags)
	local capturableFlags = CalculateCapturableFlags(totalFlags, alliedFlags)

	PrintFlagDebugInfo(alliedFlags, opponentFlags, neutralFlags, totalFlags, capturableFlags, teamIsLosing)
    
    searchDestroy = CalculateSearchDestroyValue(capturableFlags, alliedFlags, opponentFlags)
	
	if waveNumber <= 1 then
        shuffleFlags(flags)
    end
	local firstEnemyFlagEncountered = false

	return GetRandomItem(flags, function(f)
		if not botDefender then
			-- bot prioritize one flag (1st in flags table that is enemy)
			local priority
			priority, firstEnemyFlagEncountered = calculateAttackerPriority(f, enemyTeam, team, firstEnemyFlagEncountered)
			return priority
		else
			return calculateDefenderPriority(f, enemyTeam, team)
		end
	end)
end

function GotoNextWaypoint(squad)
	local waypoints = BotApi.Scene.Waypoints
	BotApi.Commands:CaptureFlag(squad, waypoints[math.random(#waypoints)]) --captureflag is basically gothereandattack
	if printDebug then print("[ARM] Print: #captureFlag call inside GoToNextWaypoint") end
end

function OnWaypoint(args)
	if printDebug then print("[ARM] Print: #GotoNextWaypoint call inside OnWaypoint") end

	if IsReservedArtillerySquad(args.squadId) then
		return
	end

	GotoNextWaypoint(args.squadId)
end

local function SceneVar(name, default)
	local v = BotApi.Scene:GetVar(name)
	if v ~= nil then
		return v
	end
	return default
end

local function SetSceneVar(name, value)
	BotApi.Scene:SetVar(name, value)
end

local function CancelAmbushStallTimer()
	if ambushStallTimer then
		BotApi.Events:KillQuantTimer(ambushStallTimer)
		ambushStallTimer = nil
	end
end

local function BeginAmbushRestore(reason)
	if AmbushEventState.restoring then
		return
	end

	CancelAmbushStallTimer()

	AmbushEventState.spawning = false
	AmbushEventState.relocating = false
	AmbushEventState.restoring = true

	SetSceneVar("ai_ambush_active", 0)

	if type(KillSpawnWaitTimer) == "function" then
		KillSpawnWaitTimer()
	end

	if Context then
		Context.SpawnInfo = nil

		if Context.SpawnWait then
			Context.SpawnWait.RetryPendingUnit = false
		end
	end

	SetSceneVar("ai_ambush_restore_done", 0)
	SetSceneVar("ai_ambush_restore_request", 1)

	print(
		"[AMBUSH] RESTORE REQUESTED" ..
		" reason=" .. tostring(reason) ..
		" spawned=" .. tostring(AmbushEventState.spawned) ..
		"/" .. tostring(AmbushEventState.target)
	)
end

local function RestartAmbushStallTimer()
	CancelAmbushStallTimer()

	if not AmbushEventState.spawning then
		return
	end

	ambushStallTimer = BotApi.Events:SetQuantTimer(function()
		ambushStallTimer = nil

		if AmbushEventState.spawning then
			print(
				"[AMBUSH] STALLED - NO SPAWN FOR " ..
				tostring(AMBUSH_STALL_TIMEOUT / 1000) ..
				" SECONDS"
			)

			BeginAmbushRestore("SPAWN STALLED")
		end

	end, AMBUSH_STALL_TIMEOUT)
end

local function StartAmbushEvent()
	if AmbushEventState.active or ambushEventTriggered then
		return
	end

	ambushEventTriggered = true

	AmbushEventState.active = true
	AmbushEventState.warning = true
	AmbushEventState.relocating = false
	AmbushEventState.spawning = false
	AmbushEventState.restoring = false
	AmbushEventState.spawned = 0
	AmbushEventState.target = 10

	SetSceneVar("ai_ambush_active", 0)
	SetSceneVar("ai_ambush_done", 0)
	SetSceneVar("ai_ambush_spawned", 0)

	SetSceneVar("ai_ambush_relocate_request", 0)
	SetSceneVar("ai_ambush_spawn_ready", 0)

	SetSceneVar("ai_ambush_restore_request", 0)
	SetSceneVar("ai_ambush_restore_done", 0)

	print(
		"[AMBUSH] EVENT WARNING STARTED" ..
		" playerSpawn=" ..
		tostring(BotApi.Conquest.PlayerSpawnPoint)
	)

	SetSceneVar("ai_ambush_warning_request", 1)

	ambushWarningTimer = BotApi.Events:SetQuantTimer(function()
		ambushWarningTimer = nil

		AmbushEventState.warning = false
		AmbushEventState.relocating = true

		-- Do NOT clear the spawn cooldown here.
		-- We must wait until DCG has finished moving the spawn points.

		SetSceneVar("ai_ambush_spawn_ready", 0)
		SetSceneVar("ai_ambush_relocate_request", 1)

		print(
			"[AMBUSH] RELOCATION REQUESTED" ..
			" playerSpawn=" ..
			tostring(BotApi.Conquest.PlayerSpawnPoint)
		)

	end, 20 * 1000)
end

local function UpdateAmbushRelocationState()

	if AmbushEventState.relocating
	and SceneVar("ai_ambush_spawn_ready", 0) == 1
	then

		SetSceneVar("ai_ambush_spawn_ready", 0)

		AmbushEventState.relocating = false
		AmbushEventState.spawning = true

		SetSceneVar("ai_ambush_active", 1)

		if type(KillSpawnCooldownTimer) == "function" then
			KillSpawnCooldownTimer()
		end

		if type(KillSpawnWaitTimer) == "function" then
			KillSpawnWaitTimer()
		end

		if Context then
			Context.SpawnInfo = nil

			if Context.SpawnWait then
				Context.SpawnWait.RetryPendingUnit = false
			end
		end

		if Context
		and Context.Purchase
		and type(UpdateUnitToSpawn) == "function"
		then
			UpdateUnitToSpawn(Context.Purchase)
		end

		print(
			"[AMBUSH] SPAWN RELOCATION COMPLETE - SPAWNING STARTED"
		)

		RestartAmbushStallTimer()

		return
	end

	if AmbushEventState.restoring
	and SceneVar("ai_ambush_restore_done", 0) == 1
	then

		SetSceneVar("ai_ambush_restore_done", 0)

		AmbushEventState.restoring = false
		AmbushEventState.active = false

		SetSceneVar("ai_ambush_active", 0)
		SetSceneVar("ai_ambush_done", 1)

		if type(KillSpawnCooldownTimer) == "function" then
			KillSpawnCooldownTimer()
		end

		if type(SetSpawnCooldownTimer) == "function" then
			SetSpawnCooldownTimer()
		end

		print(
			"[AMBUSH] SPAWN POINTS RESTORED - EVENT COMPLETE"
		)

		return
	end
end

local AMBUSH_CHANCE = 0.1

local ambushDelayTimer = nil
local ambushDelayReady = false
local ambushRollDone = false

local function IsAmbushTierAllowed()
	return SceneVar("tier2", 0) == 1
end

local function StartAmbushDelayTimer()
	if ambushDelayTimer
	or ambushDelayReady
	or ambushRollDone
	or ambushEventTriggered
	then
		return
	end

	local delaySeconds = math.random(500, 800)							-- Arm edited 260826 (600 1200) - (500 800)
	local delayMs = delaySeconds * 1000

	ambushDelayTimer = BotApi.Events:SetQuantTimer(function()

		ambushDelayTimer = nil
		ambushDelayReady = true

	end, delayMs)
end

local function UpdateAmbushEventScheduler()

	if botDefender then
		return
	end

	if SceneVar("prep_inform", 0) ~= 1 then
		return
	end

	if ambushEventTriggered then
		return
	end

	if ambushRollDone then
		return
	end

	if not IsAmbushTierAllowed() then
		return
	end

	if not ambushDelayReady then
		StartAmbushDelayTimer()
		return
	end

	if SceneVar("ai_artillery_order", 0) == 1 then
		return
	end

	ambushRollDone = true

	local roll = math.random()

	print(
		"[AMBUSH] CHANCE ROLL=" ..
		tostring(roll) ..
		" required<=" ..
		tostring(AMBUSH_CHANCE)
	)

	if roll <= AMBUSH_CHANCE then
		print("[AMBUSH] CHANCE SUCCESS")
		StartAmbushEvent()
	else
		print("[AMBUSH] CHANCE FAILED - NO AMBUSH THIS BATTLE")
	end
end

local ArtilleryOrderState = {
	bought = 0,
	target = 0,
	toSpawn = 0,
	lastResetState = 0
}

local function RollArtilleryCount()
	return math.random(3, 5)										-- Arm edited 260826 (1 3) - (3 5)
end

local PendingArtillerySpawnTag = false
local PendingArtillerySpawnUnit = nil

local ScriptedArtillerySquads = {}

local function IsReservedArtillerySquad(squad)
	if not squad or squad == 0 then
		return false
	end

	return ScriptedArtillerySquads[squad] == true
end

local function HasType(unitInfo, wanted)
	if not unitInfo or not unitInfo.type then
		return false
	end

	for _, v in ipairs(unitInfo.type) do
		if v == wanted then
			return true
		end
	end

	return false
end

local function TypeList(unitInfo)
	if not unitInfo or not unitInfo.type then
		return "nil"
	end

	local out = {}
	for _, v in ipairs(unitInfo.type) do
		table.insert(out, tostring(v))
	end
	return table.concat(out, ",")
end

-- < [ ADD ARM REPLACER START ] 
local function IsArtilleryPiece(unitInfo)
    -- Только буксируемая артиллерия: Cannon + Artillery, без MLRS и без Tank
    return HasType(unitInfo, "Cannon") 
       and HasType(unitInfo, "Artillery") 
       and not HasType(unitInfo, "MLRS")
end
-- > [ ADD ARM REPLACER END ]

local function IsAmbushUnit(unitInfo)
	return HasType(unitInfo, "Ambush")
end

-- < [ ADD ARM REPLACER START ]:
-- (type_filter) Модифицирован цикл с учётом фильтра роли (защитник)
-- (doctrine)
local function GetOrderedAmbushUnit(units)
    if not units then
        return nil
    end

    local unitsToSpawn = {}
    local nation = BotApi.Instance.army
    local doctrineName = Doctrine.getDoctrineName()

    for _, unit in pairs(units) do
        local min_team = unit.min_team or 0
        local available = BotApi.Commands:IsUnitAvailable(unit.unit)

        if UnitLimiter.isUnitAvailable(unit)
            and UnitFilter.isUnitAllowed(unit, botDefender)
            and Doctrine.isUnitAllowed(unit, botDefender)
            and teamSize >= min_team
            and available
            and IsAmbushUnit(unit)
        then
            table.insert(unitsToSpawn, unit)
        end
    end

    if #unitsToSpawn == 0 then
        return nil
    end

    local picked = GetRandomItem(unitsToSpawn, function(t)
        return t.priority
    end)

    if picked then
        picked.ordered_ambush = true
        print(
            "[AMBUSH] PICKED=" .. tostring(picked.unit) ..
            " spawned=" .. tostring(AmbushEventState.spawned) ..
            "/" .. tostring(AmbushEventState.target)
        )
    end

    return picked
end
-- > [ ADD ARM REPLACER END ] (doctrine+priority):

local function IsArtilleryOrderEnabled()
	return SceneVar("ai_artillery_order", 0) == 1
end

function GameModeSpawnCooldown()

	if AmbushEventState.spawning then
		return math.random(2 * 1000, 7 * 1000)
	end

	if IsArtilleryOrderEnabled() and ArtilleryOrderState.toSpawn > 0 then
		return 8 * 1000
	end

	WaveAttack()

	local spawnTime
	local startSpawnTime = GetStartSpawnTime()
	local spawnCooldownTime = GetSpawnCooldownTime()

	if botDefender and firstPurchase then
		spawnTime = {
			Min = startSpawnTime.DefenseMin,
			Max = startSpawnTime.DefenseMax
		}
	elseif firstPurchase then
		spawnTime = {
			Min = startSpawnTime.AttackMin,
			Max = startSpawnTime.AttackMax
		}
	elseif not waveSpawnActive then
		spawnTime = {
			Min = spawnCooldownTime.DCGWaveOffMin,
			Max = spawnCooldownTime.DCGWaveOffMax
		}
	else
		spawnTime = {
			Min = spawnCooldownTime.DCGMin,
			Max = spawnCooldownTime.DCGMax
		}
	end

	local cooldown = math.random(spawnTime.Min, spawnTime.Max)
	firstPurchase = false
	return cooldown
end

local function RefreshArtilleryOrderState()
	local resetNow = SceneVar("ai_artillery_order_reset", 0) == 1

	if resetNow and ArtilleryOrderState.lastResetState == 0 then
		ArtilleryOrderState.bought = 0
		SetSceneVar("ai_artillery_order_reset", 0)
		SetSceneVar("ai_artillery_bought", 0)
		SetSceneVar("ai_artillery_done", 0)
	end

	ArtilleryOrderState.lastResetState = resetNow and 1 or 0
end

-- < [ ADD ARM REPLACER START ] 
-- (type_filter): Модифицирован цикл с учётом фильтра роли (защитник)
-- (doctrine): Добавлена проверка Doctrine.isUnitAllowed(unit, botDefender)
local function GetOrderedArtilleryUnit(units)
    if not units then
        return nil
    end

    local unitsToSpawn = {}
    local nation = BotApi.Instance.army
    local doctrineName = Doctrine.getDoctrineName()

    for _, unit in pairs(units) do
        local min_team = unit.min_team or 0
        local available = BotApi.Commands:IsUnitAvailable(unit.unit)
        local isArtillery = IsArtilleryPiece(unit)

        if UnitLimiter.isUnitAvailable(unit)
            and UnitFilter.isUnitAllowed(unit, botDefender)
            and Doctrine.isUnitAllowed(unit, botDefender)
            and teamSize >= min_team
            and available
            and isArtillery
        then
            table.insert(unitsToSpawn, unit)
        end
    end

    if #unitsToSpawn == 0 then
        return nil
    end

    local picked = GetRandomItem(unitsToSpawn, function(t)
        return t.priority
    end)

    if picked then
        picked.ordered_artillery = true
        print(
            "[ARTY] PICKED=" .. tostring(picked.unit) ..
            " priority=" .. tostring(picked.priority) ..
            " types=" .. TypeList(picked)
        )
    end

    return picked
end
-- > [ ADD ARM REPLACER END ] (type_filter):

function GetModeSpecificUnitToSpawn(purchase, units)

	if AmbushEventState.relocating
	or AmbushEventState.restoring
	then
		return nil
	end

	if AmbushEventState.spawning then

		if AmbushEventState.spawned >= AmbushEventState.target then
			return nil
		end

		if not purchase or not purchase.purchases or not purchase.idx then
			return nil
		end

		local startIdx = purchase.idx
		local idx = startIdx
		local firstPass = true

		while idx do
			local entry = purchase.purchases[idx]
			local currentUnits = entry and entry.Units

			local ambushUnit = GetOrderedAmbushUnit(currentUnits)

			if ambushUnit then
				ambushUnit.ordered_ambush = true
				return ambushUnit
			end

			idx = next(purchase.purchases, idx)

			if idx == nil then
				idx = next(purchase.purchases, nil)
			end

			if not firstPass and idx == startIdx then
				break
			end

			firstPass = false
		end

		return nil
	end

	RefreshArtilleryOrderState()

	if not IsArtilleryOrderEnabled() then
		return nil
	end

	if ArtilleryOrderState.target <= 0 then
		return nil
	end

	if ArtilleryOrderState.toSpawn <= 0 then
		return nil
	end
		
	if not purchase then
		return nil
	end

	if not purchase.purchases then
		return nil
	end

	if not purchase.idx then
		return nil
	end

	local startIdx = purchase.idx
	local idx = startIdx
	local firstPass = true

	while idx do
		local entry = purchase.purchases[idx]
		local currentUnits = entry and entry.Units

		local artilleryUnit = GetOrderedArtilleryUnit(currentUnits)

		if artilleryUnit then
			artilleryUnit.ordered_artillery = true

			PendingArtillerySpawnTag = true
			PendingArtillerySpawnUnit = artilleryUnit.unit

			return artilleryUnit
		end

		idx = next(purchase.purchases, idx)
		if idx == nil then
			idx = next(purchase.purchases, nil)
		end

		if not firstPass and idx == startIdx then
			break
		end

		firstPass = false
	end

	return nil
end

-- < [ ADD ARM START ] (limiter): Добавлен вызов UnitLimiter.onUnitSpawned для обычных юнитов
function OnUnitPurchased()
    local spawnInfo = Context and Context.SpawnInfo

    if spawnInfo
    and (spawnInfo.ordered_ambush or spawnInfo.ordered_artillery)
    then
        OnModeSpecificUnitSpawned(spawnInfo)
        return
    end

    if spawnInfo and spawnInfo.unit then
        UnitLimiter.onUnitSpawned(spawnInfo)
        TankInfantryRatio.onUnitSpawned(spawnInfo)
        if TankInfantryRatio.isTank(spawnInfo) then
            TankInfantryRatio.onTankSpawned()
        end
        -- < [ ADD ARM ADDED START ]:
        Multiplier.onUnitSpawned(spawnInfo)
		CostTracker.onUnitSpawned(spawnInfo)
        -- > [ ADD ARM ADDED END ]
    end

    if enableWaveCounter then
        WaveUnitCounter()
    end
end
-- > [ ADD ARM END ] (limiter):

-- < [ ADD ARM START ] (limiter): Добавлены вызовы UnitLimiter.onUnitSpawned в ветках ambush и artillery
function OnModeSpecificUnitSpawned(spawnInfo)
    if not spawnInfo then
        return
    end

    if spawnInfo.ordered_ambush then
        if spawnInfo.unit then
            UnitLimiter.onUnitSpawned(spawnInfo)
            TankInfantryRatio.onUnitSpawned(spawnInfo)
            if TankInfantryRatio.isTank(spawnInfo) then
                TankInfantryRatio.onTankSpawned()
            end
        end

        AmbushEventState.spawned = AmbushEventState.spawned + 1
        RestartAmbushStallTimer()
        SetSceneVar("ai_ambush_spawned", AmbushEventState.spawned)

        if AmbushEventState.spawned >= AmbushEventState.target then
            BeginAmbushRestore("TARGET COMPLETE")
        end
        return
    end

    if spawnInfo.ordered_artillery then
        if spawnInfo.unit then
            UnitLimiter.onUnitSpawned(spawnInfo)
            TankInfantryRatio.onUnitSpawned(spawnInfo)
            if TankInfantryRatio.isTank(spawnInfo) then
                TankInfantryRatio.onTankSpawned()
            end
        end

        if SceneVar("ai_artillery_warning_fired", 0) == 0 then
            SetSceneVar("ai_artillery_warning_fired", 1)
            SetSceneVar("ai_artillery_warning_request", 1)
        end

        ArtilleryOrderState.bought = ArtilleryOrderState.bought + 1
        ArtilleryOrderState.toSpawn = math.max(ArtilleryOrderState.target - ArtilleryOrderState.bought, 0)
        SetSceneVar("ai_artillery_bought", ArtilleryOrderState.bought)

        if ArtilleryOrderState.target > 0
        and ArtilleryOrderState.bought >= ArtilleryOrderState.target
        then
            ArtilleryOrderState.target = 0
            ArtilleryOrderState.toSpawn = 0
            SetSceneVar("ai_artillery_done", 1)
            SetSceneVar("ai_artillery_order", 0)
            SetSceneVar("ai_artillery_order_reset", 0)
        end
        return
    end
end
-- > [ ADD ARM END ] (limiter):

local function ShouldAllowArtilleryOrder()
	local userTeam = SceneVar("user_team", 0)

	return userTeam > 0
end

local function StartArtilleryOrder()
	if SceneVar("ai_artillery_order", 0) == 1 then
		return
	end

	ArtilleryOrderState.bought = 0
	ArtilleryOrderState.target = RollArtilleryCount()
	ArtilleryOrderState.toSpawn = ArtilleryOrderState.target
	ArtilleryOrderState.lastResetState = 0

	waveSpawnActive = true
	waveSpawnPossible = true
	waveUnitCount = 0

	SetSceneVar("ai_artillery_order", 1)
	SetSceneVar("ai_artillery_order_reset", 1)
	SetSceneVar("ai_artillery_bought", 0)
	SetSceneVar("ai_artillery_done", 0)
	SetSceneVar("ai_artillery_warning_fired", 0)
	SetSceneVar("ai_artillery_target_count", ArtilleryOrderState.target)
end

local ARTY_TEST_DELAY = 30 * 1000 -- 30 seconds
local artilleryStartDelayDone = false
local artilleryStartDelayTimer = nil

local function StartArtilleryStartDelay()
	if artilleryStartDelayDone or artilleryStartDelayTimer then
		return
	end

	artilleryStartDelayTimer = BotApi.Events:SetQuantTimer(function()
		artilleryStartDelayTimer = nil
		artilleryStartDelayDone = true
	end, ARTY_TEST_DELAY)
end

local DEBUG_SKIP_ARTY_DELAY = false

local function RollArtilleryDelayMs()
	local roll = math.random()

	if roll < 0.15 then
		return 700 * 1000
	elseif roll < 0.30 then
		return 750 * 1000
	elseif roll < 0.45 then
		return 800 * 1000
	elseif roll < 0.60 then
		return 850 * 1000
	elseif roll < 0.70 then
		return 900 * 1000
	elseif roll < 0.80 then
		return 1000 * 1000
	else
		return 1100 * 1000
	end
end

local artilleryOrderTriggered = false
local artilleryRollDone = false

local artilleryDelayTimer = nil
local artilleryDelayReady = false

local function StartArtilleryDelayTimer()
	if artilleryDelayTimer or artilleryDelayReady or artilleryOrderTriggered then
		return
	end

	local delayMs = RollArtilleryDelayMs()

	artilleryDelayTimer = BotApi.Events:SetQuantTimer(function()
		artilleryDelayTimer = nil
		artilleryDelayReady = true
	end, delayMs)
end

local function UpdateArtilleryOrderScheduler()

	if artilleryOrderTriggered then
		return
	end

	if artilleryRollDone then
		return
	end

	if not botDefender
	and SceneVar("prep_inform", 0) ~= 1
	then
		return
	end

	if AmbushEventState.active then
		return
	end

	if not ShouldAllowArtilleryOrder() then
		return
	end

	StartArtilleryStartDelay()

	if not artilleryStartDelayDone then
		return
	end

	if DEBUG_SKIP_ARTY_DELAY then
		artilleryDelayReady = true
	end

	if not artilleryDelayReady then
		StartArtilleryDelayTimer()
		return
	end

	artilleryRollDone = true

	local roll = math.random()

	if roll <= 0.65 then												-- Arm edited (0.35)-(0.65)

		print("[ARTY] CHANCE SUCCESS")

		StartArtilleryOrder()

		if SceneVar("ai_artillery_order", 0) == 1 then
			artilleryOrderTriggered = true
		end

	else
		print(
			"[ARTY] CHANCE FAILED - NO ARTILLERY ORDER THIS BATTLE"
		)
	end
end

function OnGameQuant()
	UpdateArtilleryOrderScheduler()
	UpdateAmbushEventScheduler()
	UpdateAmbushRelocationState()

	if not AmbushEventState.relocating
	and not AmbushEventState.restoring
	then
		-- Спавн-логика (без изменения utility.lua)
		if not Context.SpawnWait.CooldownTimer then
			if not Context.SpawnWait.WaitTimer then
				if BotApi.Commands:CanSpawn() then
					if spawningUnit then
						-- Завершаем предыдущий спавн
						if OnUnitPurchased then
							OnUnitPurchased()
						elseif enableWaveCounter then
							WaveUnitCounter()
						end
						KillSpawnWaitTimer()
						Context.SpawnInfo = nil
						SetSpawnCooldownTimer()
						spawningUnit = nil
					else
						local retryPendingUnit = Context.SpawnWait.RetryPendingUnit
						Context.SpawnWait.RetryPendingUnit = false

						if not retryPendingUnit or not Context.SpawnInfo then
							UpdateUnitToSpawn(Context.Purchase)
						end

						if Context.SpawnInfo then
							local unit = Context.SpawnInfo.unit
							if BotApi.Commands:IsUnitAvailable(unit) then
								if GameModeSpawnUnit(unit, MaxSquadSize) then
									spawningUnit = true
								else
									local currentUnitSpawnWaitTime = GetCurrentSpawnWaitTime()
									local tts = BotApi.Commands:TimeToSpawnUnit(unit)
									local min_tts = GetUnitSelectionTTSLimit()
									if tts > min_tts then
										KillSpawnWaitTimer()
										Context.SpawnInfo = nil
									else
										if retryPendingUnit then
											Context.SpawnInfo = nil
										end
										if not Context.SpawnWait.WaitTimer then
											if printDebug then
												print("Print: player#".. BotApi.Instance.playerId .." tried to purchase: ".. unit .." Not enough MP, DP, CP, or the unit timer is not unlocked")
												print("Print: player#".. BotApi.Instance.playerId .." will wait a maximum of ".. (currentUnitSpawnWaitTime / 1000 + 1) .."s for resources or unit timer before it attempts a new unit purchase")
											end
											Context.SpawnWait.WaitTimer = BotApi.Events:SetQuantTimer(
												function()
													Context.SpawnWait.WaitTimer = nil
													Context.SpawnWait.RetryPendingUnit = Context.SpawnInfo ~= nil
												end, currentUnitSpawnWaitTime + 1000)
										end
									end
								end
							else
								KillSpawnWaitTimer()
								Context.SpawnInfo = nil
							end
						end
					end
				end
			end
		end
	end

	local waypoints = BotApi.Scene.Waypoints

	if #waypoints == 0 then
		for i, squad in pairs(BotApi.Scene.Squads) do
			if not IsReservedArtillerySquad(squad) and not Context.SquadTimers[squad] then
				SetSquadOrder(CaptureFlag, squad, OrderRotationPeriod)
			end
		end
	end
    -- < [ ADD ARM START ]: (debuger) Логирование ресурсов каждый тик
    -- ResourcesDebug.onQuant()
    -- > [ ADD ARM END ]:	
end

-- NOTE: Returns true if squad tagged "_lua_mi" or "_lua_alert".
-- NOTE: "_lua_mi" = reserved for mission script use.
-- NOTE: "_lua_alert" = squad abruptly runs into enemy force seek&destroy.
function IsSquadInScript(squad)

	if IsReservedArtillerySquad(squad) then
		return true
	end

	if BotApi.Scene:IsSquadTagged(squad, "turret_brake")
	or BotApi.Scene:IsSquadTagged(squad, "gun_brake")
	or BotApi.Scene:IsSquadTagged(squad, "ai_lunge_mine_busy")
	or BotApi.Scene:IsSquadTagged(squad, "i_see_you")

	then
		if printDebug then
			print("[ARM] Print: SQUADinSCRIPT thus no action squad", squad, "Player#", BotApi.Instance.playerId, "Team", team)
		end
		return true
	end

	if BotApi.Scene:IsSquadTagged(squad, "_lua_mi") or BotApi.Scene:IsSquadTagged(squad, "repairing") then
		if printDebug then print("[ARM] Print: SQUADinSCRIPT thus no action squad", squad, "Player#",BotApi.Instance.playerId, "Team", team) end
		return true
	elseif BotApi.Scene:IsSquadTagged(squad, "_lua_alert") then
		if printDebug then print("[ARM] Print: SQUADinALERT thus seek by squad", squad, "Player#",BotApi.Instance.playerId, "Team", team) end
		BotApi.Commands:SeekAndDestroy(squad)
		return true
	end
end

	-- NOTE: Returns true if squad tagged "_lua_ignore" for general ignore.
function IsSquadToIgnore(squad)
	if BotApi.Scene:IsSquadTagged(squad, "_lua_ignore") then
		return true
	end
end

function CaptureFlag(squad)
	local flags = {}
    for i, flag in pairs(BotApi.Scene.Flags) do
        table.insert(flags, {id = i, name = flag.name, priority = getDefaultFlagPriority(flag), owner = flag.occupant})
    end
	
	local flag = GetFlagToCapture(BotApi.Scene.Flags, getDefaultFlagPriority, flags)

	if not flag then
		if printDebug then print("[ARM] Print: No Flags so SeekAndDestroy by squad ", squad, "Player#", BotApi.Instance.playerId) end
		BotApi.Commands:SeekAndDestroy(squad)
		return
	end

	if IsSquadInScript(squad) then
		return
	end

	if IsSquadToIgnore(squad) then
		local rndAI = math.random()
		if searchDestroy > rndAI then
			if printDebug then print("[ARM] Print: [see_enemy] seek by squad ", squad, "Player#", BotApi.Instance.playerId) end
			BotApi.Commands:SeekAndDestroy(squad)
			return
		else
			if printDebug then print("[ARM] Print: [see_enemy] donothing by squad ", squad, "Player#", BotApi.Instance.playerId) end
			return
		end
	end

	if printDebug then print("[ARM] Print: [notags] ctf by squad", squad, "Player#", BotApi.Instance.playerId, "Flag name: ", flag.name) end
	return BotApi.Commands:CaptureFlag(squad, flag.name)
end

function GetCurrentSpawnWaitTime()

	if AmbushEventState.spawning then
		return 5 * 1000
	end

	return UnitSpawnWaitTime
end

-- <<< [ ADD ARM REPLACER START ] (type_filter): Модифицирован цикл с учётом фильтра роли (защитник)
-- << [ ADD ARM REPLACER START ] (doctrine): Добавлена проверка Doctrine.isUnitAllowed(unit, botDefender)
function GetUnitToSpawn(units)
    if AmbushEventState.relocating
    or AmbushEventState.spawning
    or AmbushEventState.restoring
    then
        return nil
    end

    if not units then
        return nil
    end

    local income = BotApi.Commands:Income(BotApi.Instance.playerId)

    -- Вспомогательная функция для сбора доступных юнитов с дополнительным фильтром
    local function collectUnits(additionalFilter)
        local result = {}
        for _, unit in pairs(units) do
            local min_team = unit.min_team or 0
            local min_income = unit.min_income or -1
            local available = BotApi.Commands:IsUnitAvailable(unit.unit)

            local allowed = UnitLimiter.isUnitAvailable(unit)
                and UnitFilter.isUnitAllowed(unit, botDefender)
                and Doctrine.isUnitAllowed(unit, botDefender)
                and teamSize >= min_team
                and income >= min_income
                and available
                and not IsArtilleryPiece(unit)

            if allowed and (additionalFilter == nil or additionalFilter(unit)) then
                table.insert(result, unit)
            end
        end
        return result
    end

    -- Если есть ожидающая пехота, применяем двухуровневый приоритет
    if TankInfantryRatio.isInfantryPriority() then
        -- 1) Сначала собираем primary (приоритет 4.0)
        local primaryUnits = collectUnits(function(unit)
            return TankInfantryRatio.isPrimaryInfantry(unit)
        end)

        if #primaryUnits > 0 then
            return GetRandomItem(primaryUnits, function(t)
                local priority = t.priority
                local function UnitType(val)
                    if not t.type then return false end
                    for _, value in ipairs(t.type) do
                        if value == val then return true end
                    end
                    return false
                end
                if UnitType("Squad") then priority = priority * 1.75 end
                if UnitType("Cannon") then priority = priority * 0.80 end
                return priority
            end)
        end

        -- 2) Если primary нет, собираем secondary
        local secondaryUnits = collectUnits(function(unit)
            return TankInfantryRatio.isSecondaryInfantry(unit)
        end)

        if #secondaryUnits > 0 then
            return GetRandomItem(secondaryUnits, function(t)
                local priority = t.priority
                local function UnitType(val)
                    if not t.type then return false end
                    for _, value in ipairs(t.type) do
                        if value == val then return true end
                    end
                    return false
                end
                if UnitType("Squad") then priority = priority * 1.75 end
                if UnitType("Cannon") then priority = priority * 0.80 end
                return priority
            end)
        end

        -- 3) Если нет ни primary, ни secondary, берём любые доступные юниты (чтобы не застрять)
        local fallbackUnits = collectUnits(nil)
        if #fallbackUnits > 0 then
            return GetRandomItem(fallbackUnits, function(t)
                local priority = t.priority
                local function UnitType(val)
                    if not t.type then return false end
                    for _, value in ipairs(t.type) do
                        if value == val then return true end
                    end
                    return false
                end
                if UnitType("Squad") then priority = priority * 1.75 end
                if UnitType("Cannon") then priority = priority * 0.80 end
                return priority
            end)
        else
            -- Если вообще нет доступных юнитов, возвращаем nil (бот подождёт)
            if printDebug then
                print("[ARM] No units available for spawn after all filters")
            end
            return nil
        end
    end

    -- Если нет ожидающей пехоты, обычный сбор всех доступных юнитов
    local allUnits = collectUnits(nil)
    if #allUnits == 0 then
        if printDebug then
            print("[ARM] No units available for spawn after filters")
        end
        return nil
    end

    return GetRandomItem(allUnits, function(t)
        local priority = t.priority
        local function UnitType(val)
            if not t.type then return false end
            for _, value in ipairs(t.type) do
                if value == val then return true end
            end
            return false
        end
        if UnitType("Squad") then priority = priority * 1.75 end
        if UnitType("Cannon") then priority = priority * 0.80 end
        return priority
    end)
end
-- > [ ADD ARM REPLACER END ] (doctrine):
-- >> [ ADD ARM REPLACER END ] (type_filter):

-- < [ ADD ARM REPLACER END ]:
function OnGameStart()
    UnitLimiter.init()
    Multiplier.reset()

    isAttackerOrDefender()

    if not botDefender then
        Doctrine.selectDoctrine()
        if printDebug then
            print("[ARM] (Doctrine): Doctrine activated for attacker: " .. Doctrine.getDoctrineName())
        end
    else
        if printDebug then
            print("[ARM] (Doctrine): Bot is defender, doctrine disabled")
        end
    end

    local defenseLevel = BotApi.Scene:GetVar("defense_level") or 1
    if defenseLevel < 1 then defenseLevel = 1 end
    if defenseLevel > 3 then defenseLevel = 3 end
    currentBattleNumber = defenseLevel

    if printDebug then
        print("[ARm] (WAve): Defense level obtained: " .. defenseLevel)
        print(string.format("[ARm] (WAve): Using defenseLevel as battle proxy: %d", currentBattleNumber))
    end

    PendingArtillerySpawnTag = false
    PendingArtillerySpawnUnit = nil

    SetSceneVar("prep_inform", 0)
    SetSceneVar("ai_artillery_engaged", 0)
    SetSceneVar("ai_artillery_tag_request", 0)
    SetSceneVar("ai_artillery_tag_busy", 0)
    SetSceneVar("ai_artillery_on", 0)
    SetSceneVar("ai_artillery_loop_busy", 0)
    SetSceneVar("ai_ambush_warning_request", 0)
    SetSceneVar("ai_ambush_active", 0)
    SetSceneVar("ai_ambush_done", 0)
    SetSceneVar("ai_ambush_spawned", 0)
    SetSceneVar("ai_ambush_relocate_request", 0)
    SetSceneVar("ai_ambush_spawn_ready", 0)
    SetSceneVar("ai_ambush_restore_request", 0)
    SetSceneVar("ai_ambush_restore_done", 0)

    setVarsInMissionScript()

    waveUnitTotal = RollWaveUnitTotal()
    if printDebug then
        print("[ARM] Print: difficulty =", tostring(GetBotDifficultyKey()))
        print("[ARM] Print: waveUnitTotal", waveUnitTotal)
    end

    BotApi.Events:SetQuantTimer(function()
        if ARm_ReduceAircraft then ARm_ReduceAircraft() end
        if ARm_ZeroPrototypes then ARm_ZeroPrototypes() end
    end, 2000)

    -- Загружаем покупки (это создаёт глобальную таблицу Purchases)
    OnGameStartUtility("conquest")

    -- Теперь, когда покупки загружены, инициализируем CostTracker и балансир
    CostTracker.prepare()   -- строим карту cost
    CostTracker.init()      -- запоминаем время (теперь оно доступно)
    TankInfantryRatio.init()
end
-- > [ ADD ARM REPLACER END ]:

-- Notifies the mission script that player defense prep time is over.
function OnPrepTimeOver()
	BotApi.Scene:SetVar("prep_inform", 1)
	if printDebug then print("[ARM] Print: prep_inform set to 1, Player defense prep is over.") end
end

BotApi.Events:Subscribe(BotApi.Events.GameStart, OnGameStart)
BotApi.Events:Subscribe(BotApi.Events.GameEnd, OnGameStop)
BotApi.Events:Subscribe(BotApi.Events.Quant, OnGameQuant)
BotApi.Events:Subscribe(BotApi.Events.GameSpawn, OnGameSpawn)
BotApi.Events:Subscribe(BotApi.Events.Waypoint, OnWaypoint)
BotApi.Events:Subscribe(BotApi.Events.PrepTimeOver, OnPrepTimeOver)
