-- File: 		conquest_tank_infantry_ratio.lua
-- Catalog: 	script\multiplayer\modes
-- Format:		LUA
-- Description: Проактивный балансир пехоты/танков: после каждого танка спавнится N пехоты с повышенным двухуровневым приоритетом.
-- Created by:	Max Drechsler
-- Created: 	27.08.2026
-- Modified: 	27.08.26 
-- Version 4.2

-- File: conquest_tank_infantry_ratio.lua
-- Version 4.3 (без множителей)

local M = {}

local infantryPerTank = {
    ger = 2,
    rus = 3,
    fin = 3,
    usa = 2,
    eng = 2,
}

local priorityInfantryTags = {
    ger = {
        primary = {"Infantry", "Squad", "PzGren"},
        secondary = {"Infantry", "Squad", "Reg"}
    },
    rus = {
        primary = {"Infantry", "Squad", "Storm"},
        secondary = {"Infantry", "Squad", "Reg"}
    },
    fin = {
        primary = {"Infantry", "Squad"},
        secondary = {"Infantry", "Squad"}
    },
    usa = {
        primary = {"Infantry", "Squad"},
        secondary = {"Infantry", "Squad"}
    },
    eng = {
        primary = {"Infantry", "Squad"},
        secondary = {"Infantry", "Squad"}
    },
}

local pendingInfantrySpawns = 0

local function logBalancer(msg)
    if printDebug then
        print("[ARm] (Tank-Infantry Balancer): " .. msg)
    end
end

local function hasType(unit, typeName)
    if not unit or not unit.type then return false end
    for _, t in ipairs(unit.type) do
        if t == typeName then return true end
    end
    return false
end

function M.isTank(unit)
    if not unit or not unit.type then return false end
    -- Игнорируем амбушные юниты
    for _, t in ipairs(unit.type) do
        if t == "Ambush" then
            return false
        end
    end
    -- Если есть "Squad" или "TankTeam" - это не танк, а группы танков или шторм-отряды
    for _, t in ipairs(unit.type) do
        if t == "Squad" or t == "TankTeam" then
            return false
        end
    end
    local hasTank = false
    for _, t in ipairs(unit.type) do
        if t == "Tank" then hasTank = true break end
    end
    if not hasTank then return false end

    local hasMedium, hasHeavy, hasMain, hasTD = false, false, false, false
    for _, t in ipairs(unit.type) do
        if t == "Medium" then hasMedium = true end
        if t == "Heavy" then hasHeavy = true end
        if t == "Main" then hasMain = true end
        if t == "TD" then hasTD = true end
    end
    return (hasMedium and hasMain) or (hasHeavy and hasMain) or hasTD
end

function M.isInfantry(unit)
    return hasType(unit, "Squad") or hasType(unit, "Infantry")
end

-- Проверка, является ли юнит primary-пехотой
function M.isPrimaryInfantry(unit)
    if not M.isInfantry(unit) then return false end
    local nation = BotApi.Instance.army
    local tags = priorityInfantryTags[nation]
    if not tags then return false end
    local primary = tags.primary or {}
    for _, tag in ipairs(primary) do
        if not hasType(unit, tag) then return false end
    end
    return true
end

-- Проверка, является ли юнит secondary-пехотой
function M.isSecondaryInfantry(unit)
    if not M.isInfantry(unit) then return false end
    if M.isPrimaryInfantry(unit) then return false end -- primary не считается secondary
    local nation = BotApi.Instance.army
    local tags = priorityInfantryTags[nation]
    if not tags then return false end
    local secondary = tags.secondary or {}
    for _, tag in ipairs(secondary) do
        if not hasType(unit, tag) then return false end
    end
    return true
end

function M.onTankSpawned()
    local nation = BotApi.Instance.army
    local count = infantryPerTank[nation] or 0
    if count > 0 then
        pendingInfantrySpawns = pendingInfantrySpawns + count
        logBalancer(string.format("Tank spawned, pending infantry +%d (total: %d)", count, pendingInfantrySpawns))
    else
        logBalancer(string.format("Tank spawned, nation '%s' has no infantryPerTank, ignoring", nation))
    end
end

function M.onUnitSpawned(unit)
    if not unit or not unit.unit then return end
    if not M.isInfantry(unit) then return end
    if pendingInfantrySpawns > 0 then
        pendingInfantrySpawns = pendingInfantrySpawns - 1
        logBalancer(string.format("Infantry spawned (%s), remaining: %d", unit.unit, pendingInfantrySpawns))
    end
end

function M.isInfantryPriority()
    return pendingInfantrySpawns > 0
end

function M.init()
    pendingInfantrySpawns = 0
    logBalancer("Module initialized (proactive infantry spawning)")
end

function M.onQuant()
    -- не используется
end

return M