-- File: conquest_doctrine.lua
-- Catalog: script\multiplayer\modes
-- Modify by Max Drechsler 
-- Created 26.08.2026
-- Modify 27.08.2026
-- Version 1.14 (с отладкой)
-- Модуль доктрин с вероятностным выбором (Default + 5 доктрин для Германии)
-- Каждая доктрина имеет собственные фильтры (без глобальных)

local M = {}

local function hasType(unit, wanted)
    if not unit or not unit.type then
        return false
    end
    for _, t in ipairs(unit.type) do
        if t == wanted then
            return true
        end
    end
    return false
end

-- ============================================================
-- Доктрина 1: "Infanterie Division with Panzerjager-Abteilung"
-- Запрещены: LW, Gebirgs, SS, Aircraft, PzGren
-- ============================================================
local function infantryFilter(unit)
    if not unit or not unit.type then
        return false
    end
    for _, t in ipairs(unit.type) do
        if t == "LW" or t == "Gebirgs" or t == "SS" or t == "Aircraft" or t == "PzGren" then
            return false
        end
    end

    local hasInfantry  = hasType(unit, "Infantry")
    local hasSquad     = hasType(unit, "Squad")
    local hasTeam      = hasType(unit, "Team")
    local hasCannon    = hasType(unit, "Cannon")
    local hasVehicle   = hasType(unit, "Vehicle")
    local hasArmored   = hasType(unit, "Armored")
    local hasTank      = hasType(unit, "Tank")
    local hasHalftrack = hasType(unit, "Halftrack")
    local hasTransport = hasType(unit, "Transport")
    local hasMotorize  = hasType(unit, "Motorize")
    local hasTruck     = hasType(unit, "Truck")
    local hasMG        = hasType(unit, "MG")
    local hasAA        = hasType(unit, "AA")
    local hasAT        = hasType(unit, "AT")
    local hasMortar    = hasType(unit, "Mortar")
    local hasSupport   = hasType(unit, "Support")
    local hasArtillery = hasType(unit, "Artillery")
    local hasHowitzer  = hasType(unit, "Howitzer")
    local hasMLRS      = hasType(unit, "MLRS")
    local hasHunter    = hasType(unit, "Hunter")
    local hasUnarmed   = hasType(unit, "Unarmed")

    if hasInfantry and hasSquad then
        if hasMotorize and not hasTruck then
            return false
        end
        return true
    end
    if hasInfantry and hasTeam then
        return true
    end
    if hasCannon then
        if hasAA then return true end
        if hasAT then return true end
        if hasMortar then return true end
        if hasSupport then return true end
        if hasArtillery and hasHowitzer then return true end
        if hasArtillery and hasMLRS then return true end
        return false
    end
    if hasVehicle and not hasHalftrack then
        if hasMG then return true end
        if hasAA then return true end
        if hasUnarmed then return true end
        return false
    end
    if hasArmored and not hasHalftrack and not hasTransport then
        if hasMG then return true end
        if hasAA then return true end
        if hasAT then return true end
        if hasSupport then return true end
        return false
    end
    if hasHalftrack then
        if hasArmored and hasAA and hasAT then return true end
        if hasVehicle and hasAT then return true end
        if hasArmored and hasArtillery and hasMLRS then return true end
        return false
    end
    if hasTank and hasAT and hasHunter then
        return true
    end
    return false
end

-- ============================================================
-- Доктрина 2: "Panzer Battalion (Light/Medium)"
-- Запрещены: LW, Gebirgs, SS, Aircraft, PzGren
-- ============================================================
local function panzerFilter(unit)
    if not unit or not unit.type then
        return false
    end
    for _, t in ipairs(unit.type) do
        if t == "LW" or t == "Gebirgs" or t == "SS" or t == "Aircraft" or t == "PzGren" then
            return false
        end
    end

    local hasInfantry  = hasType(unit, "Infantry")
    local hasSquad     = hasType(unit, "Squad")
    local hasCannon    = hasType(unit, "Cannon")
    local hasVehicle   = hasType(unit, "Vehicle")
    local hasTank      = hasType(unit, "Tank")
    local hasLight     = hasType(unit, "Light")
    local hasMedium    = hasType(unit, "Medium")
    local hasMotorize  = hasType(unit, "Motorize")
    local hasMortar    = hasType(unit, "Mortar")
    local hasUnarmed   = hasType(unit, "Unarmed")
    local hasSupply    = hasType(unit, "Supply")
    local hasAT        = hasType(unit, "AT")
    local hasTD        = hasType(unit, "TD")

    if hasInfantry and hasSquad and hasMotorize then
        return true
    end
    if hasTank and (hasLight or hasMedium) then
        if hasAT or hasTD then
            return false
        end
        return true
    end
    if hasCannon and hasMortar then
        return true
    end
    if hasVehicle and hasUnarmed and hasSupply then
        return true
    end
    return false
end

-- ============================================================
-- Доктрина 3: "Heavy Panzer Battalion with PzGren (Motorized)"
-- Запрещены: LW, Gebirgs, SS, Aircraft
-- Разрешён PzGren
-- ============================================================
local function heavyPanzerFilter(unit)
    if not unit or not unit.type then
        return false
    end
    for _, t in ipairs(unit.type) do
        if t == "LW" or t == "Gebirgs" or t == "SS" or t == "Aircraft" then
            return false
        end
    end

    local hasInfantry  = hasType(unit, "Infantry")
    local hasSquad     = hasType(unit, "Squad")
    local hasVehicle   = hasType(unit, "Vehicle")
    local hasTank      = hasType(unit, "Tank")
    local hasHeavy     = hasType(unit, "Heavy")
    local hasMotorize  = hasType(unit, "Motorize")
    local hasUnarmed   = hasType(unit, "Unarmed")
    local hasSupply    = hasType(unit, "Supply")

    if hasInfantry and hasSquad and hasMotorize then
        return true
    end
    if hasTank and hasHeavy then
        return true
    end
    if hasVehicle and hasUnarmed and hasSupply then
        return true
    end
    return false
end

-- ============================================================
-- Доктрина 4: "Gebirgsjäger Light Tank Battalion"
-- Запрещены: LW, SS, Aircraft, Motorize, PzGren
-- Разрешены: Gebirgs (пехота), Tank+Light (без AT/TD/Artillery/Support/Hunter)
-- ============================================================
local function gebirgsLightTankFilter(unit)
    if not unit or not unit.type then
        return false
    end
    for _, t in ipairs(unit.type) do
        if t == "LW" or t == "SS" or t == "Aircraft" or t == "Motorize" or t == "PzGren" then
            return false
        end
    end

    local hasInfantry  = hasType(unit, "Infantry")
    local hasSquad     = hasType(unit, "Squad")
    local hasTeam      = hasType(unit, "Team")
    local hasGebirgs   = hasType(unit, "Gebirgs")
    local hasTank      = hasType(unit, "Tank")
    local hasLight     = hasType(unit, "Light")
    local hasAT        = hasType(unit, "AT")
    local hasTD        = hasType(unit, "TD")
    local hasArtillery = hasType(unit, "Artillery")
    local hasSupport   = hasType(unit, "Support")
    local hasHunter    = hasType(unit, "Hunter")
    local hasVehicle   = hasType(unit, "Vehicle")
    local hasUnarmed   = hasType(unit, "Unarmed")
    local hasSupply    = hasType(unit, "Supply")

    if hasInfantry and (hasSquad or hasTeam) and hasGebirgs then
        return true
    end
    if hasTank and hasLight then
        if hasAT or hasTD or hasArtillery or hasSupport or hasHunter then
            return false
        end
        return true
    end
    if hasVehicle and hasUnarmed and hasSupply then
        return true
    end
    return false
end

-- ============================================================
-- Доктрина 5: "Luftwaffe Field Division with Fallschirmjäger"
-- Запрещены: SS, PzGren, TD, Hunter
-- Разрешены: Aircraft, Infantry+Squad+LW, Tank+Medium/Heavy, Cannon+AA/Mortar, Armored+AA+Halftrack, Vehicle+Unarmed+Supply
-- ============================================================
local function luftwaffeFilter(unit)
    if not unit or not unit.type then
        return false
    end
    for _, t in ipairs(unit.type) do
        if t == "SS" or t == "PzGren" or t == "TD" or t == "Hunter" then
            return false
        end
    end

    local hasAircraft  = hasType(unit, "Aircraft")
    local hasInfantry  = hasType(unit, "Infantry")
    local hasSquad     = hasType(unit, "Squad")
    local hasLW        = hasType(unit, "LW")
    local hasTank      = hasType(unit, "Tank")
    local hasMedium    = hasType(unit, "Medium")
    local hasHeavy     = hasType(unit, "Heavy")
    local hasCannon    = hasType(unit, "Cannon")
    local hasAA        = hasType(unit, "AA")
    local hasMortar    = hasType(unit, "Mortar")
    local hasArmored   = hasType(unit, "Armored")
    local hasHalftrack = hasType(unit, "Halftrack")
    local hasVehicle   = hasType(unit, "Vehicle")
    local hasUnarmed   = hasType(unit, "Unarmed")
    local hasSupply    = hasType(unit, "Supply")

    if hasAircraft then
        return true
    end
    if hasInfantry and hasSquad and hasLW then
        return true
    end
    if hasInfantry then
        return false
    end
    if hasTank and (hasMedium or hasHeavy) then
        return true
    end
    if hasCannon and (hasAA or hasMortar) then
        return true
    end
    if hasArmored and hasAA and hasHalftrack then
        return true
    end
    if hasVehicle and hasUnarmed and hasSupply then
        return true
    end
    return false
end

-- ============================================================
-- Список доктрин для Германии (5 штук)
-- ============================================================
-- local GermanDoctrines = {
--     {
--         name = "Infanterie Division with Panzerjager-Abteilung",
--         types = {"Infantry", "Cannon", "Vehicle", "Armored", "Tank"},
--         filter = infantryFilter
--     },
--     {
--         name = "Panzer Battalion (Light/Medium)",
--         types = {"Infantry", "Tank", "Cannon", "Vehicle"},
--         filter = panzerFilter
--     },
--     {
--         name = "Heavy Panzer Battalion with PzGren (Motorized)",
--         types = {"Infantry", "Tank", "Vehicle"},
--         filter = heavyPanzerFilter
--     },
--     {
--         name = "Gebirgsjäger Light Tank Battalion",
--         types = {"Infantry", "Tank", "Vehicle"},
--         filter = gebirgsLightTankFilter
--     },
--     {
--         name = "Luftwaffe Field Division with Fallschirmjäger",
--         types = {"Aircraft", "Infantry", "Tank", "Cannon", "Armored", "Vehicle"},
--         filter = luftwaffeFilter
--     },
-- }

local GermanDoctrines = {}

-- ============================================================
-- Таблица доктрин по нациям
-- ============================================================
local Doctrines = {
    ger = GermanDoctrines,
    rus = {},
    usa = {},
    eng = {},
    fin = {},
    jap = {},
}

local selectedDoctrine = nil
local nation = nil

-- ============================================================
-- Выбор доктрины (с отладкой)
-- ============================================================
function M.selectDoctrine()
    nation = BotApi.Instance.army
    if not nation then
        if printDebug then
            print("[ARM] (Doctrine): ERROR: Nation not defined, doctrines disabled")
        end
        selectedDoctrine = nil
        return
    end

    local doctrines = Doctrines[nation] or {}
    local numDoctrines = #doctrines

    -- ОТЛАДКА: выводим количество и имена доктрин
    print("[DEBUG] Nation: " .. tostring(nation))
    print("[DEBUG] Number of doctrines for " .. nation .. ": " .. tostring(numDoctrines))
    for i, d in ipairs(doctrines) do
        print("[DEBUG] Doctrine " .. i .. ": " .. tostring(d.name))
    end

    local options = {}
    for _, d in ipairs(doctrines) do
        table.insert(options, { type = "doctrine", data = d })
    end
    table.insert(options, { type = "default", data = nil })

    print("[DEBUG] Options count: " .. tostring(#options))

    local idx = math.random(1, #options)
    print("[DEBUG] Random index: " .. tostring(idx))
    local chosen = options[idx]
    print("[DEBUG] Chosen type: " .. tostring(chosen.type))

    if chosen.type == "default" then
        selectedDoctrine = {
            name = "Default",
            types = {"Infantry", "Cannon", "Tank", "Armored", "Vehicle", "Aircraft", "Artillery", "Support", "AT", "AA", "Mortar", "MLRS"},
            filter = nil
        }
        if printDebug then
            print("[ARM] (Doctrine): Default doctrine for nation " .. nation .. " (no restrictions)")
        end
    else
        selectedDoctrine = chosen.data
        if printDebug then
            print("[ARM] (Doctrine): Selected " .. selectedDoctrine.name .. " for nation " .. nation)
        end
    end
end

function M.isUnitAllowed(unit, isDefender)
    if isDefender then
        return true
    end
    if not selectedDoctrine then
        return true
    end
    if not unit then
        return false
    end

    local ok = false
    for _, allowedType in ipairs(selectedDoctrine.types) do
        if hasType(unit, allowedType) then
            ok = true
            break
        end
    end
    if not ok then
        return false
    end

    if selectedDoctrine.filter then
        return selectedDoctrine.filter(unit)
    end

    return true
end

function M.getDoctrineName()
    return selectedDoctrine and selectedDoctrine.name or "None"
end

return M